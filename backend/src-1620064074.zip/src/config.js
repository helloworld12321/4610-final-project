'use strict';

/**
 * Some global constants.
 */

exports.CITY_DATA_TABLE = 'CityData';
exports.ROUTES_TABLE = 'Routes';
exports.ROUTES_INDEX_SORTED_BY_DISTANCE = 'sorted-index';
